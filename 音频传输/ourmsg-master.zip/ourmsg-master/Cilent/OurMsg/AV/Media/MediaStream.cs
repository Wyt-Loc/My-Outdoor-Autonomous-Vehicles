﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LumiSoft.Net.Media
{
    /// <summary>
    /// This class represents single media stream in multimedia session.
    /// </summary>
    abstract public class MediaStream
    {
    }
}
