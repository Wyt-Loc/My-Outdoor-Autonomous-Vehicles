﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LumiSoft.Net.Media
{
    /// <summary>
    /// This class implements PCM audio receiver.
    /// </summary>
    public class AudioIn
    {
        /// <summary>
        /// 
        /// </summary>
        public AudioIn()
        {
        }


        #region Properties implementation

        #endregion

    }
}
