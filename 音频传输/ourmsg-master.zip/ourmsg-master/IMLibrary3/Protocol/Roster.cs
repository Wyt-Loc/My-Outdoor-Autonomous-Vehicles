﻿using System;
using System.Collections.Generic;
using System.Text;

namespace IMLibrary3.Protocol
{
    /// <summary>
    /// 分组信息
    /// </summary>
    public class DownloadGroups : Element
    { 
    }

    /// <summary>
    /// 用户信息
    /// </summary>
    public class  DownloadUsers : Element
    {
      
    }

    /// <summary>
    /// 群
    /// </summary>
    public class DownloadRooms : Element
    {
       
    }
}
