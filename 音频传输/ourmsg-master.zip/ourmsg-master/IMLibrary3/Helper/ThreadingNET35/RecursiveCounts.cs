namespace Helper.ThreadingNET35
{
    using System;

    internal class RecursiveCounts
    {
        public int upgradecount;
        public int writercount;
    }
}

