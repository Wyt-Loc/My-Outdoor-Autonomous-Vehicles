namespace Helper.ThreadingNET35
{
    using System;

    public enum LockRecursionPolicy
    {
        NoRecursion,
        SupportsRecursion
    }
}

