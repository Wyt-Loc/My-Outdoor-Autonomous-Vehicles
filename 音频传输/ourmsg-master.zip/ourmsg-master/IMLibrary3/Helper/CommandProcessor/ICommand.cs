using System;
using System.Collections.Generic;
using System.Text;

namespace Helper.CommandProcessor
{
	public interface ICommand
	{
		void Execute();
	}
}
