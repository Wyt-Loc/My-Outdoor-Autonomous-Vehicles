using System;

namespace IMLibrary3.Net
{
	/// <summary>
	/// Log entry type.
	/// </summary>
    [Obsolete("Get rid of it.")]
	public enum SocketLogEntryType
	{
		/// <summary>
		/// Data is readed from remote endpoint.
		/// </summary>
		ReadFromRemoteEP = 0,

		/// <summary>
		/// Data is sent to remote endpoint.
		/// </summary>
		SendToRemoteEP = 1,

		/// <summary>
		/// Comment log entry.
		/// </summary>
		FreeText = 2,
	}
}
