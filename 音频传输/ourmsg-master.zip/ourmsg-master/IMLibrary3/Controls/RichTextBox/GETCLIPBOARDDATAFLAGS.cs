﻿using System;
using System.Collections.Generic;
using System.Text;

namespace IMLibrary3
{
    public enum GETCLIPBOARDDATAFLAGS
    {
        RECO_PASTE = 0,
        RECO_DROP = 1,
        RECO_COPY = 2,
        RECO_CUT = 3,
        RECO_DRAG = 4
    }
}
