﻿using System;
using System.Collections.Generic;
using System.Text;

namespace IMLibrary3.Organization
{
    /// <summary>
    /// GroupVcard
    /// </summary>
    public class GroupVcard : Group
    {
        /// <summary>
        /// 协议类型
        /// </summary>
        public IMLibrary3.Protocol.type type { get; set; }

    }
}
