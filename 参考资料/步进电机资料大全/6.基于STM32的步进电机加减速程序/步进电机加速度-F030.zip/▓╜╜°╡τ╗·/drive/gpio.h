#ifndef __GPIO_H
#define	__GPIO_H

#include "stm32f0xx.h"




void IO_Init(void);
//void PUL(unsigned char pul);


#endif /* __LED_H */

