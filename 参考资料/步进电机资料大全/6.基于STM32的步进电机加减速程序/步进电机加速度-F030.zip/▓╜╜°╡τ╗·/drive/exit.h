#ifndef __EXIT_H
#define	__EXIT_H

#include "stm32f0xx.h"

void EXIT_KEY_Init(void);

#endif /* __EXIT_H */
