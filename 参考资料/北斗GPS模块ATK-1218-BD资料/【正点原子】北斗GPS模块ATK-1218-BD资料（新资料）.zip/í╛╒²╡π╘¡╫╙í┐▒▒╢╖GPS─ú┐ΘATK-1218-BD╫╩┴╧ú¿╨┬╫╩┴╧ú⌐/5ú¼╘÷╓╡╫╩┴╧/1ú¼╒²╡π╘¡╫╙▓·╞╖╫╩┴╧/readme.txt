感谢您选择正点原子的产品


为了更好的维护资料，以及让客户随时下载正点原子最新的开发板、产品、模块资料，我们
使用文档中心的方式，给大家提供最新最全的资料下载链接，您可以通过：

1，点击本目录下的：请点击进入资料下载地址.html
2，直接登录：http://www.openedv.com/docs/index.html

进入正点原子文档中心，获取最新最全的资料。

后续，我们将不再在增值资料里面放置模块资料了，统一改到文档中心下载。


特此说明！




 ***********************************************************************************************************
 * 公司名称：广州市星翼电子科技有限公司（正点原子）
 * 电话号码：020-38271790
 * 传真号码：020-36773971
 * 公司网址：www.alientek.com
 * 购买地址：zhengdianyuanzi.tmall.com
 * 技术论坛：http://www.openedv.com/forum.php
 * 最新资料：www.openedv.com/docs/index.html
 *
 * 在线视频：www.yuanzige.com
 * B 站视频：space.bilibili.com/394620890
 * 公 众 号：mp.weixin.qq.com/s/y--mG3qQT8gop0VRuER9bw
 * 抖    音：douyin.com/user/MS4wLjABAAAAi5E95JUBpqsW5kgMEaagtIITIl15hAJvMO8vQMV1tT6PEsw-V5HbkNLlLMkFf1Bd
 ***********************************************************************************************************