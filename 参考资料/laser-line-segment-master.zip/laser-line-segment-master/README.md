A novel algorithm about laser line segment extarction using 2D laser data.

> H. Gao, X. Zhang*, Y. Fang, J. Yuan, A line segment extraction algorithm using laser data based on seeded region growing, Int. Journal of Advanced Robotic Systems, 2018, 15(1).

[Video demo](https://youtu.be/yNN9NRioOBc)

[More information about our research group](http://www.xuebozhang.net/)
