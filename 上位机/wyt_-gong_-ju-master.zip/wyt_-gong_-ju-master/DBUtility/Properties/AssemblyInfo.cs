﻿using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("TCMS.DBUtility")]
[assembly: AssemblyDescription("Data Access Application Model By Atide")]
[assembly: AssemblyConfiguration("xxxxx")]
[assembly: AssemblyCompany("xxxxx")]
[assembly: AssemblyProduct("TCMS.DBUtility")]
[assembly: AssemblyCopyright("Copyright (C) Atidesoft 2004-2010")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: AssemblyVersion("3.5.0")]
[assembly: AssemblyDelaySign(false)]
[assembly: AssemblyKeyFile("")]
[assembly: AssemblyKeyName("")]
